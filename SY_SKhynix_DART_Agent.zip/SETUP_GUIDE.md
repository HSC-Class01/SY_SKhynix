# GitHub 업로드 순서

이 ZIP은 업로드가 어려운 hidden 파일을 포함하지 않도록 구성했습니다.

1. ZIP을 풀고 파일들을 저장소 루트에 업로드합니다.
2. `WORKFLOW_COPY_update-and-deploy.yml` 파일의 내용을 복사합니다.
3. GitHub에서 `.github/workflows/update-and-deploy.yml` 경로로 새 파일을 만들고 붙여넣습니다.
4. `Settings → Secrets and variables → Actions → New repository secret`
   - Name: `DART_API_KEY`
   - Value: OpenDART에서 발급받은 40자리 키
5. `Settings → Pages → Source: GitHub Actions`를 선택합니다.
6. `Actions`에서 `Update DART data and deploy dashboard`를 `Run workflow`로 한 번 수동 실행합니다.

주의:
- API 키는 README, Python 코드, JSON 파일에 직접 넣지 않습니다.
- `.env`도 GitHub에 올리지 않습니다.
- OpenDART의 `fnlttSinglAcntAll` API는 현재 개발가이드상 2015년 이후 데이터를 제공합니다. 2010~2014는 자동 재무수치 수집과 별도로 레거시 소스를 추가해야 합니다.
