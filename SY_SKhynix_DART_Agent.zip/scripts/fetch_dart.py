import csv
import io
import json
import os
import time
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import requests

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RAW = DATA / "raw"
RAW.mkdir(parents=True, exist_ok=True)

BASE = "https://opendart.fss.or.kr/api"
KEY = os.getenv("DART_API_KEY", "").strip()

if not KEY:
    raise SystemExit("DART_API_KEY is not set. Add it to GitHub Actions Secrets or your local environment.")

CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
STOCK = CONFIG["stock_code"]
START_YEAR = int(CONFIG["start_year"])
END_YEAR = int(os.getenv("END_YEAR", time.strftime("%Y")))
REPORTS = CONFIG["report_codes"]

session = requests.Session()
session.headers.update({"User-Agent": "SY_SKhynix-DART-Agent/1.0"})

def get_json(endpoint, params):
    params = dict(params)
    params["crtfc_key"] = KEY
    r = session.get(f"{BASE}/{endpoint}.json", params=params, timeout=60)
    r.raise_for_status()
    obj = r.json()
    if str(obj.get("status")) not in ("000", "013"):
        raise RuntimeError(f"DART {endpoint}: {obj.get('status')} {obj.get('message')}")
    return obj

def resolve_corp_code():
    cfg_code = CONFIG.get("corp_code", "").strip()
    if cfg_code:
        return cfg_code

    cache = DATA / "corp_codes.json"
    if not cache.exists():
        r = session.get(f"{BASE}/corpCode.xml", params={"crtfc_key": KEY}, timeout=60)
        r.raise_for_status()
        cache.write_bytes(r.content)

    with zipfile.ZipFile(cache) as z:
        name = z.namelist()[0]
        xml_bytes = z.read(name)

    root = ET.fromstring(xml_bytes)
    for item in root.findall("list"):
        stock = (item.findtext("stock_code") or "").strip()
        if stock == STOCK:
            return (item.findtext("corp_code") or "").strip()

    raise RuntimeError(f"Could not resolve corp_code for stock code {STOCK}")

def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def collect_report(year, label, reprt_code):
    # OpenDART full financial statements are available from 2015 in the current API guide.
    if year < 2015:
        return {"year": year, "label": label, "status": "legacy_metadata_only"}

    params = {
        "corp_code": CORP_CODE,
        "bsns_year": str(year),
        "reprt_code": reprt_code,
        "fs_div": CONFIG["fs_div"],
    }
    obj = get_json("fnlttSinglAcntAll", params)
    save_json(RAW / f"{year}_{label}.json", obj)
    return {"year": year, "label": label, "status": "collected", "count": len(obj.get("list", []))}

CORP_CODE = resolve_corp_code()
CONFIG["corp_code"] = CORP_CODE
(ROOT / "config.json").write_text(json.dumps(CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")

results = []
for year in range(START_YEAR, END_YEAR + 1):
    for label, code in REPORTS.items():
        try:
            results.append(collect_report(year, label, code))
        except Exception as exc:
            results.append({"year": year, "label": label, "status": "error", "error": str(exc)})
        time.sleep(0.2)

save_json(DATA / "collection_log.json", {
    "corp_code": CORP_CODE,
    "stock_code": STOCK,
    "start_year": START_YEAR,
    "end_year": END_YEAR,
    "results": results,
})

print(json.dumps(results[-8:], ensure_ascii=False, indent=2))
