import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "docs" / "data"
OUT.mkdir(parents=True, exist_ok=True)

METRICS = {
    "매출액": ["매출액", "수익(매출액)", "Revenue", "Sales"],
    "영업이익": ["영업이익", "영업이익(손실)", "Operating income", "Operating profit"],
    "당기순이익": ["당기순이익", "당기순이익(손실)", "Profit for the period", "Net income"],
    "자산총계": ["자산총계", "Assets"],
    "부채총계": ["부채총계", "Liabilities"],
    "자본총계": ["자본총계", "Equity"],
    "유동자산": ["유동자산", "Current assets"],
    "유동부채": ["유동부채", "Current liabilities"],
}

def num(v):
    if v is None:
        return None
    s = str(v).replace(",", "").strip()
    if s in ("", "-", "—"):
        return None
    try:
        return float(s)
    except ValueError:
        return None

def find_account(rows, aliases):
    aliases = {x.lower() for x in aliases}
    for row in rows:
        name = str(row.get("account_nm", "")).strip()
        if name.lower() in aliases:
            return row
    for row in rows:
        name = str(row.get("account_nm", "")).strip().lower()
        if any(a in name for a in aliases):
            return row
    return None

def extract(path):
    obj = json.loads(path.read_text(encoding="utf-8"))
    rows = obj.get("list", [])
    if not rows:
        return None

    # Prefer accumulated/current amount for income-statement items in interim reports.
    out = {}
    for metric, aliases in METRICS.items():
        row = find_account(rows, aliases)
        if not row:
            out[metric] = None
            continue
        value = row.get("thstrm_add_amount") or row.get("thstrm_amount")
        out[metric] = num(value)

    stem = path.stem
    year, report = stem.split("_", 1)
    out["year"] = int(year)
    out["report"] = report
    out["source_file"] = path.name
    return out

records = []
for path in sorted(RAW.glob("*.json")):
    if path.name in ("collection_log.json", "corp_codes.json"):
        continue
    try:
        rec = extract(path)
        if rec:
            records.append(rec)
    except Exception as exc:
        print("skip", path, exc)

# Deduplicate by year/report
records.sort(key=lambda x: (x["year"], x["report"]))
latest = {}
for r in records:
    latest[(r["year"], r["report"])] = r
records = list(latest.values())

for r in records:
    revenue = r.get("매출액")
    op = r.get("영업이익")
    net = r.get("당기순이익")
    ca = r.get("유동자산")
    cl = r.get("유동부채")
    assets = r.get("자산총계")
    liabilities = r.get("부채총계")
    equity = r.get("자본총계")

    r["영업이익률"] = op / revenue * 100 if revenue else None
    r["순이익률"] = net / revenue * 100 if revenue else None
    r["유동비율"] = ca / cl * 100 if ca is not None and cl else None
    r["부채비율"] = liabilities / equity * 100 if liabilities is not None and equity else None
    r["ROA"] = net / assets * 100 if net is not None and assets else None
    r["ROE"] = net / equity * 100 if net is not None and equity else None

fields = [
    "year","report","매출액","영업이익","당기순이익","자산총계","부채총계","자본총계",
    "유동자산","유동부채","영업이익률","순이익률","유동비율","부채비율","ROA","ROE","source_file"
]

with (OUT / "financials.csv").open("w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(records)

annual = [r for r in records if r["report"] == "annual"]
half = [r for r in records if r["report"] == "half_year"]
quarterly = [r for r in records if r["report"] in ("quarterly_q1","quarterly_q3")]

payload = {
    "company": "SK하이닉스",
    "stock_code": "000660",
    "unit": "원본 API 금액 단위(원); dashboard 표시 시 억원 환산",
    "annual": annual,
    "half_year": half,
    "quarterly": quarterly,
    "peer_firms": [
        {"name":"삼성전자","stock_code":"005930","note":"국내 메모리/반도체 종합 비교군"},
        {"name":"DB하이텍","stock_code":"000990","note":"국내 반도체 제조 비교군"},
        {"name":"한미반도체","stock_code":"042700","note":"국내 반도체 장비 비교군"},
        {"name":"주성엔지니어링","stock_code":"036930","note":"국내 반도체 장비 비교군"}
    ]
}
(OUT / "dashboard.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

print(f"Analyzed {len(records)} report datasets.")
