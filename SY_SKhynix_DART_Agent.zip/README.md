# SK hynix DART Financial Agent

SK hynix(000660) 정기보고서 기반 재무데이터 수집·분석·GitHub Pages 대시보드 프로젝트입니다.

## 핵심 기능
- OpenDART API로 사업보고서(11011), 반기보고서(11012), 1분기보고서(11013), 3분기보고서(11014) 수집
- 2015년 이후 OpenDART 재무 API가 제공하는 재무수치 자동 수집
- 2010~2014년은 OpenDART의 정기 재무 API 제공 범위 밖이므로 보고서 메타데이터를 별도로 수집하고, 과거 재무수치는 별도 레거시 데이터 소스로 확장할 수 있도록 구조화
- 주요 재무수치 및 재무비율 계산
- annual / half-year / quarterly 3개 테이블 생성
- GitHub Actions로 매월 1일 자동 업데이트
- GitHub Pages 정적 대시보드 배포
- 국내 peer firms 표 제공

## API Key 설정

GitHub 저장소:
`Settings → Secrets and variables → Actions → New repository secret`

Name:
`DART_API_KEY`

Value:
OpenDART에서 발급받은 40자리 인증키

로컬에서는 환경변수:
`DART_API_KEY=...`

API 키를 코드나 Git에 직접 입력하지 마세요.

## 실행

```bash
python scripts/fetch_dart.py
python scripts/analyze.py
```

## GitHub Pages

Repository `Settings → Pages`에서 Source를 `GitHub Actions`로 선택합니다.

워크플로는 `.github/workflows/update-and-deploy.yml` 하나만 사용합니다.

## 주요 수치
- 매출액
- 영업이익
- 당기순이익
- 자산총계
- 부채총계
- 자본총계
- 유동자산
- 유동부채
- 영업이익률
- 순이익률
- 유동비율
- 부채비율
- ROA
- ROE

## 국내 Peer Firms
Peer는 동일 사업구조가 완전히 같은 기업이라는 뜻이 아니라 국내 반도체 산업 비교군입니다.

| 기업 | 종목코드 | 비교 관점 |
|---|---:|---|
| 삼성전자 | 005930 | 메모리/반도체 종합 |
| DB하이텍 | 000990 | 반도체 제조 |
| 한미반도체 | 042700 | 반도체 후공정 장비 |
| 주성엔지니어링 | 036930 | 반도체 장비 |

## 주의
OpenDART `fnlttSinglAcntAll` API는 현재 개발가이드상 2015년 이후 데이터를 제공합니다. 따라서 2010~2014년의 동일한 재무 API 자동수집을 전제로 하면 데이터 공백이 생깁니다. 이 패키지는 그 구간을 억지로 만들어내지 않고 별도 레거시 확장 지점으로 남겨 둡니다.
